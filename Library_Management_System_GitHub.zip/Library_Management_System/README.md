# Library Management System in C++

A beginner-friendly, menu-driven Library Management System built using C++ and Object-Oriented Programming (OOP). It uses in-memory storage only, so no file handling or database is required.

## Features

- Add a book with its ID, title, and author
- Display all books and their availability
- Search for a book by ID
- Issue an available book
- Return an issued book
- Validate duplicate IDs and common invalid inputs

## OOP Concepts Demonstrated

- **Classes and Objects:** `Book` and `Library`
- **Encapsulation:** Book details are private and accessed through public methods
- **Abstraction:** Library operations are provided through simple member functions
- **Constructor:** Initializes each book's details and availability
- **Composition:** `Library` stores a collection of `Book` objects

## Requirements

- A C++ compiler that supports C++11 or newer (for example, g++)

## Compile and Run

### Linux / macOS
```bash
g++ -std=c++11 -Wall -Wextra -pedantic main.cpp -o library
./library
```

### Windows (MinGW)
```bash
g++ -std=c++11 -Wall -Wextra -pedantic main.cpp -o library.exe
library.exe
```

## How to Use

1. Run the program.
2. Select an option from the menu.
3. Follow the prompts to add, search, issue, or return a book.
4. Select `6` to exit.

## Important Note

Books are stored in memory while the program is running. All book records are lost when the program exits. This is intentional because the project does not use file handling.

## Project Structure

```text
Library_Management_System/
├── main.cpp
├── README.md
├── .gitignore
└── LICENSE
```

## Future Improvements

- Student/member records
- Issue and return dates
- Fine calculation
- File handling or database storage
- Login system
